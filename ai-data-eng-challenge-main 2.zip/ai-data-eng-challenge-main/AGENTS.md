# Conventions

A trimmed replica of our platform conventions. Follow these in your submission.

**Tech stack:** Apache Airflow 2.10 (prod MWAA runs 2.10.3; local Astro Runtime 12.12.0 ships
2.10.5 — same minor line), dbt-core 1.8.7, Python 3.10+, DuckDB (the warehouse — embedded, runs
anywhere), Terraform (applied via Terraform Cloud).

## Warehouse layers (medallion)

We use **medallion** layers, but only two of them — there is no S3 / bronze. Data flows left to
right, all inside the DuckDB warehouse:

- **`silver`** — flattened source records, landed by the Airflow ingestion DAG straight into
  `silver.<source>_<table>` (typed-as-text, one `refdate` partition per load). Idempotent:
  re-running a `refdate` replaces that partition's rows.
- **`gold`** — modeled, typed, deduplicated dbt tables (the curated, query-ready layer). dbt
  models live under `models/gold/<source>/` and read `silver` via `source()`.

## DAG structure

```
source_to_destination/
├── dag.py        # orchestration ONLY (folder name MUST match the dag_id minus _{env})
├── assets.py     # config, table lists, SQL/strategy helpers
└── README.md     # data contract (grain, partitioning, idempotency, freshness)
```

Standard pattern:

```python
ENVIRONMENT = os.environ.get("AIRFLOW__CORE__ENVIRONMENT", "dev")

default_args = {
    "owner": "owner_name",
    "execution_timeout": timedelta(minutes=600),     # required
    "retries": 3,
}

with DAG(dag_id=f"pipeline_name_{ENVIRONMENT}", default_args=default_args,
         concurrency=1, max_active_runs=1) as dag:
    dag.doc_md = doc_md  # required
    ...
```

### API sources — source-strategy / factory pattern (convention)

We don't ship a generic API helper — when a pipeline needs to pull from an HTTP API, build a
small extraction utility (`utils/api_operations.py`) yourself, landing records into `silver`
via the provided `utils/duckdb_operations.py` helper. The pattern we favour: one **strategy
class per source** that builds request headers + query params, registered in a small
**factory**, so adding a source is a one-line change and credentials stay per-source.

```python
# Sketch — your design may differ.
def get_source(name):
    return {
        "github": GitHubSource(),   # builds Bearer header + since/pagination params
    }[name]
```

## dbt / SQL conventions

- Source-based naming by layer — no `stg_`/`fct_`/`dim_` prefixes. Models live under
  `models/gold/<source>/`.
- **Leading commas**, UPPERCASE SQL functions (`CAST`, `COALESCE`, `ROW_NUMBER`), CTE-based.
- Large/event-style tables are **incremental** (you choose and justify the strategy) and resolve
  to one row per natural key.
- Every model carries schema tests.
- Tag models: `zone:gold`, `source:api`, `tec:airflow`.

## Testing

- Mock the HTTP layer with `unittest.mock`, and load into a throwaway DuckDB file (`tmp_path`)
  to assert what landed in `silver` — no cloud, no network. See
  `tests/airflow/test_duckdb_operations_example.py` for the pattern.
- Every `dag.py` must pass `tests/airflow/test_validation_airflow.py`.
- dbt models build + test `gold` on **DuckDB** (`dbt run/test --target duckdb`) from the `silver`
  the ingestion DAG produces — the DAG's `dbt_run`/`dbt_test` tasks, or point `DBT_DUCKDB_PATH` at
  the warehouse file to iterate locally.
- SQL style is enforced by **sqlfluff** (CI runs `sqlfluff lint models` via the dbt templater);
  config + dialect live in `dbt/duckdb/.sqlfluff`.

## Always

Folder name matches dag id; type all new code; keep `dag.py` orchestration-only; set
`execution_timeout` and `doc_md`; never commit secrets or `.env`.
