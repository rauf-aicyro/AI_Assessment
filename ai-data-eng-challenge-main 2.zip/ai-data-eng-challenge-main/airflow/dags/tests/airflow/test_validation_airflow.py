import glob
import sys
import pytest
from os import path
from airflow.models import DagBag

DAG_FILES = glob.glob(path.join(path.dirname(__file__), "..", "..", "./**/dag.py"))

sys.path.append("../")


@pytest.mark.parametrize("dag_path", DAG_FILES)
def test_for_import_errors_for_all_dags(dag_path):
    error_result = {}
    try:
        dagbag = DagBag(dag_folder=dag_path, include_examples=False)
        error_result = dagbag.import_errors
        error_message = error_result[dag_path]
    except Exception:
        error_message = None

    import_error = True
    if error_message:
        ignore_errors = ["no such table:", "isn't defined"]
        for useless_message in ignore_errors:
            if useless_message not in error_message:
                import_error = False

    if import_error:
        assert error_result == {}, f"Should be NO import errors for the dag: {dag_path}."


@pytest.mark.parametrize("dag_path", DAG_FILES)
def test_for_dags_with_at_least_one_task(dag_path):
    dagbag = DagBag(dag_folder=dag_path, include_examples=False)
    for dag in dagbag.dags:
        assert len(dagbag.dags[dag].tasks) > 0, f"The dag should have at least one task: {dagbag.dags[dag].tasks}."


@pytest.mark.parametrize("dag_path", DAG_FILES)
def test_dags_with_no_owner(dag_path):
    dagbag = DagBag(dag_folder=dag_path, include_examples=False)
    for dag in dagbag.dags:
        args_from_dags = dagbag.dags[dag].default_args.get("owner", [])
        assert args_from_dags, f"Owner is not set on dag: {dagbag.dags[dag]}."


@pytest.mark.parametrize("dag_path", DAG_FILES)
def test_dags_with_no_execution_timeout(dag_path):
    dagbag = DagBag(dag_folder=dag_path, include_examples=False)
    for dag in dagbag.dags:
        args_from_dags = dagbag.dags[dag].default_args.get("execution_timeout", [])
        assert args_from_dags, f"Dag doesn't have an `execution_timeout` set: {dagbag.dags[dag]}."


@pytest.mark.parametrize("dag_path", DAG_FILES)
def test_dags_without_doc(dag_path):
    dagbag = DagBag(dag_folder=dag_path, include_examples=False)
    for dag in dagbag.dags:
        doc_from_dag = dagbag.dags[dag].doc_md
        assert doc_from_dag, f"The following dag has no `doc_md` element: {dagbag.dags[dag]}."
