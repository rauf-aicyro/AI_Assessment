"""Example unit test showing the DuckDB silver-loading pattern used in this repo.

This is a **starting point you can copy**, not part of the validation suite. Your ingestion
will land records into the `silver` schema of the DuckDB warehouse (via
`DuckDBOperations.load_records_to_silver`). Point it at a throwaway DuckDB file in `tmp_path`,
load some records, then query them back. For the API itself, mock the HTTP layer with
`unittest.mock` (patch the `requests` session) so your tests stay deterministic and offline —
combine the two to cover your whole `api -> silver` step without any cloud or network.
"""

import os

import duckdb

from utils.duckdb_operations import DuckDBOperations


def test_load_records_then_query_them_back(tmp_path):
    db_file = str(tmp_path / "test.duckdb")
    records = [
        {"id": 1, "user": {"login": "octocat"}},
        {"id": 2, "user": {"login": "hubot"}},
    ]

    DuckDBOperations.load_records_to_silver(records, "github", "issues", refdate="20260101", duckdb_file=db_file)

    con = duckdb.connect(db_file, read_only=True)
    try:
        rows = con.execute('SELECT id, user_login, refdate FROM "silver"."github_issues" ORDER BY id').fetchall()
    finally:
        con.close()

    assert rows == [("1", "octocat", "20260101"), ("2", "hubot", "20260101")]


def test_reloading_the_same_refdate_is_idempotent(tmp_path):
    db_file = str(tmp_path / "test.duckdb")
    records = [{"id": 1}, {"id": 2}]

    DuckDBOperations.load_records_to_silver(records, "github", "issues", refdate="20260101", duckdb_file=db_file)
    DuckDBOperations.load_records_to_silver(records, "github", "issues", refdate="20260101", duckdb_file=db_file)

    con = duckdb.connect(db_file, read_only=True)
    try:
        count = con.execute('SELECT COUNT(*) FROM "silver"."github_issues"').fetchone()[0]
    finally:
        con.close()

    assert count == 2


def test_empty_records_is_a_noop(tmp_path):
    db_file = str(tmp_path / "test.duckdb")

    DuckDBOperations.load_records_to_silver([], "github", "issues", refdate="20260101", duckdb_file=db_file)

    # No records -> the loader returns before touching DuckDB, so no file is even created.
    assert not os.path.exists(db_file)
