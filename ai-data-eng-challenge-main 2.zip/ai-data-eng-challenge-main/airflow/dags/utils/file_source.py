import os
import json
import glob
import logging

from utils.duckdb_operations import DuckDBOperations

logger = logging.getLogger(__name__)


class FileSource:
    """
    Ingest newline-delimited JSON (NDJSON) file drops straight into the ``silver`` warehouse
    schema.

    Globex is a *file-drop* vendor: in prod it delivers files via SFTP; locally those files
    live under ``include/lake_seed/<source>_<table>/``. This reads every NDJSON file for a
    table and hands the records to :class:`DuckDBOperations`, which writes them idempotently
    into ``silver.<source>_<table>`` for the given ``refdate``.
    """

    @classmethod
    def read_ndjson_dir(cls, source_dir: str, source: str, table: str) -> list:
        """Read all ``*.json`` NDJSON files under ``<source_dir>/<source>_<table>/``."""
        folder = os.path.join(source_dir, f"{source}_{table}")
        files = sorted(glob.glob(os.path.join(folder, "*.json")))
        records = []
        for file_path in files:
            with open(file_path, "r") as handle:
                for line in handle:
                    line = line.strip()
                    if line:
                        records.append(json.loads(line))
        logger.info(f"===> Read {len(records)} record(s) from {len(files)} file(s) under `{folder}`.")
        return records

    @classmethod
    def files_to_silver(
        cls,
        source_dir: str,
        source: str,
        table: str,
        refdate: str,
        is_to_generate_id: bool = False,
    ) -> None:
        """Read a table's NDJSON file drops and load them into ``silver`` for one ``refdate``."""
        records = cls.read_ndjson_dir(source_dir, source, table)
        DuckDBOperations.load_records_to_silver(
            records=records,
            source=source,
            table=table,
            refdate=refdate,
            is_to_generate_id=is_to_generate_id,
        )
