import os
import logging
from uuid import uuid4
from datetime import datetime, timezone
from typing import Optional

import duckdb
import pandas as pd

logger = logging.getLogger(__name__)

SILVER_SCHEMA = "silver"
_PARTITION_COLLISIONS = {"day", "month", "year"}


def duckdb_path() -> str:
    """
    Resolve the DuckDB file the warehouse lives in.

    Both the ingestion tasks (here) and the dbt tasks read this same file, so ``silver``
    written by a DAG is exactly what the ``gold`` dbt models build from — no S3, no Spectrum,
    no extra copies. The path comes from ``DBT_DUCKDB_PATH`` (baked into the Astro image via the
    ``Dockerfile``), falling back to a local default for the no-Docker test path.
    """
    return os.environ.get("DBT_DUCKDB_PATH", "/tmp/dbt/local.duckdb")


def _clean_columns(columns: list) -> list:
    """Strip whitespace and rename columns that collide with reserved partition names."""
    cleaned = []
    for column in columns:
        name = str(column).strip()
        if name in _PARTITION_COLLISIONS:
            name = f"record_{name}"
        cleaned.append(name)
    return cleaned


class DuckDBOperations:
    """
    Thin warehouse helper: land flattened records into the ``silver`` schema of the local
    DuckDB warehouse.

    The medallion layers here are ``silver`` (typed-as-text, flattened source records, one
    partition per ``refdate``) and ``gold`` (modeled/deduplicated dbt tables). Loads are
    **idempotent by ``refdate`` partition**: re-running a given ``refdate`` deletes that
    partition's rows and reinserts them, so retries and backfills never duplicate.
    """

    @classmethod
    def records_to_frame(cls, records: list, refdate: str, is_to_generate_id: bool = False) -> pd.DataFrame:
        """Flatten nested records (``user.login`` -> ``user_login``) into an all-text frame."""
        df = pd.json_normalize(records, sep="_")
        df.columns = _clean_columns(list(df.columns))
        df = df.astype(str)
        df["refdate"] = str(refdate)
        df["reftimestamp"] = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
        if is_to_generate_id:
            df["id"] = [str(uuid4()) for _ in range(len(df))]
        return df

    @classmethod
    def _ensure_columns(cls, con: duckdb.DuckDBPyConnection, fq_table: str, df: pd.DataFrame) -> None:
        """Add any columns present in ``df`` but missing from the table (schema drift, as text)."""
        existing = {row[0] for row in con.execute(f"DESCRIBE {fq_table}").fetchall()}
        for column in df.columns:
            if column not in existing:
                con.execute(f'ALTER TABLE {fq_table} ADD COLUMN "{column}" VARCHAR')

    @classmethod
    def load_records_to_silver(
        cls,
        records: list,
        source: str,
        table: str,
        refdate: str,
        is_to_generate_id: bool = False,
        duckdb_file: Optional[str] = None,
    ) -> None:
        """
        Idempotently load ``records`` into ``silver.<source>_<table>`` for one ``refdate``.

        Args:
            records: list
                Source records (dicts), e.g. one API page or one file's NDJSON lines.
            source: str
                The data source, e.g. ``github`` or ``globex``.
            table: str
                The logical table, e.g. ``issues`` or ``orders``.
            refdate: str
                ``YYYYMMDD`` partition key. The load replaces this partition.
            is_to_generate_id: bool
                Generate a surrogate ``id`` per row when the source has no natural key.
            duckdb_file: str | None
                Override the warehouse file (tests). Defaults to :func:`duckdb_path`.
        """
        table_name = f"{source}_{table}"
        if not records:
            logger.info(f"===> No records for {source}.{table} (refdate={refdate}); nothing to load.")
            return

        df = cls.records_to_frame(records, refdate, is_to_generate_id)
        fq_table = f'"{SILVER_SCHEMA}"."{table_name}"'

        db_file = duckdb_file or duckdb_path()
        # DuckDB won't create missing parent directories — make sure they exist first.
        parent_dir = os.path.dirname(db_file)
        if parent_dir:
            os.makedirs(parent_dir, exist_ok=True)
        con = duckdb.connect(db_file)
        try:
            con.execute(f'CREATE SCHEMA IF NOT EXISTS "{SILVER_SCHEMA}"')
            con.register("incoming_records", df)
            con.execute(f"CREATE TABLE IF NOT EXISTS {fq_table} AS SELECT * FROM incoming_records LIMIT 0")
            cls._ensure_columns(con, fq_table, df)
            con.execute(f"DELETE FROM {fq_table} WHERE refdate = ?", [str(refdate)])
            con.execute(f"INSERT INTO {fq_table} BY NAME SELECT * FROM incoming_records")
        finally:
            try:
                con.unregister("incoming_records")
            except Exception:
                pass
            con.close()

        logger.info(f"===> Loaded {len(df)} rows into {SILVER_SCHEMA}.{table_name} (refdate={refdate}).")
