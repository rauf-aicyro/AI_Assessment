# globex_files_to_silver (reference example)

A minimal, working pipeline that demonstrates the repo conventions. **Use it as a style
reference — do not modify it for the challenge.**

## Data contract

- **Source**: Globex delivers newline-delimited JSON (NDJSON). In prod the files arrive via an
  SFTP export; locally they live under `include/lake_seed/globex_<table>/`. The DAG reads them
  and lands them in the `silver` warehouse schema.
- **Tables**: `orders`, `order_lines`.
- **Grain**: one row per record in the source file.
- **Partitioning**: rows are tagged with a `refdate` (`YYYYMMDD`) partition column in `silver`.
- **Idempotency**: each load is a `refdate`-partition replace — re-running a logical date
  deletes that partition's `silver` rows and reinserts them, so retries never duplicate.
- **Freshness**: daily at 03:00 UTC.

## Flow

```
start
  -> source_to_silver_globex_<table>   (NDJSON file drop -> silver.globex_<table>, per table)
  -> dbt_run_globex / dbt_test_globex  (build + test gold.globex models)
  -> end
```

## Conventions illustrated

- Folder name matches the `dag_id` (minus the `_{ENVIRONMENT}` suffix).
- `dag.py` is orchestration only; config lives in `assets.py`.
- Required `default_args`: `owner`, `execution_timeout`, `retries`.
- `doc_md` is set on the DAG.
