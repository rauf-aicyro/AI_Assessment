"""Configuration for the Globex file-drop pipeline.

Globex is an example vendor that delivers newline-delimited JSON (NDJSON) files. In prod they
arrive via an SFTP export; locally they live under ``include/lake_seed/globex_<table>/``. This
pipeline reads those files and lands them in the ``silver`` warehouse schema (DuckDB), then
builds the ``gold`` dbt models. Use it as a *style reference*; the ingestion step is a file
source, intentionally a different shape from the API source you will build for GitHub.
"""

# Directory the Globex file drops live in (inside the Astro container). The Astro project's
# `include/` is mounted at `/usr/local/airflow/include`.
SOURCE_DIR = "/usr/local/airflow/include/lake_seed"

SOURCE = "globex"

# Tables Globex delivers as <source>_<table>/ under SOURCE_DIR.
TABLES = [
    "orders",
    "order_lines",
]

DBT_MODELS = "gold.globex"
