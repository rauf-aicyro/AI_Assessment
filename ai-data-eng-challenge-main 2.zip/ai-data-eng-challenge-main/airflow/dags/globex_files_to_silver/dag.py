import os
from datetime import datetime, timedelta

from airflow import DAG
from airflow.models import Variable
from airflow.operators.empty import EmptyOperator
from airflow.operators.python import PythonOperator
from airflow_dbt.operators.dbt_operator import DbtRunOperator, DbtTestOperator

from globex_files_to_silver.assets import TABLES, DBT_MODELS, SOURCE, SOURCE_DIR
from utils.file_source import FileSource

doc_md = """ \n
### Globex files to silver — Data pipeline (REFERENCE EXAMPLE)
- *Owner*: data-engineering
- *Objective*: Ingest Globex vendor files (NDJSON) into the `silver` warehouse schema (DuckDB),
  then build the `gold` dbt models.
- *Note*: This is a reference DAG demonstrating repo conventions. Globex is a *file-drop*
  source; GitHub — the source you will build — is an *API* source, so adapt the ingestion step
  rather than copying it.
"""

ENVIRONMENT = os.environ.get("AIRFLOW__CORE__ENVIRONMENT", "dev")

default_args = {
    "owner": "data-engineering",
    "depends_on_past": False,
    "start_date": datetime(2025, 1, 1),
    "email_on_failure": False,
    "email_on_retry": False,
    "retries": 3,
    "retry_delay": timedelta(minutes=2),
    "execution_timeout": timedelta(minutes=600),
    # DBT — local DuckDB warehouse (the only target).
    "dir": Variable.get("DBT_DIRECTORY", default_var="dbt"),
    "profiles_dir": Variable.get("DBT_PROFILE_PATH", default_var="dbt"),
    "dbt_bin": Variable.get("DBT_BIN", default_var="dbt"),
    "models": DBT_MODELS,
    "target": Variable.get("DBT_TARGET", default_var="duckdb"),
}

with DAG(
    dag_id=f"globex_files_to_silver_{ENVIRONMENT}",
    default_args=default_args,
    concurrency=1,
    max_active_runs=1,
    description="Load Globex vendor file drops into silver and build gold dbt models.",
    schedule="0 3 * * *",  # Daily at 03:00 UTC
    catchup=False,
) as dag:
    dag.doc_md = doc_md
    start_task = EmptyOperator(task_id="start_task")
    inter_task = EmptyOperator(task_id="inter_task")
    end_task = EmptyOperator(task_id="end_task", trigger_rule="none_failed")

    # Idempotent partition key: re-running a logical date replaces that refdate's silver rows.
    refdate = "{{ ds_nodash }}"

    for table_name in TABLES:
        source_to_silver = PythonOperator(
            task_id=f"source_to_silver_{SOURCE}_{table_name}_{ENVIRONMENT}",
            python_callable=FileSource.files_to_silver,
            op_kwargs={
                "source_dir": SOURCE_DIR,
                "source": SOURCE,
                "table": table_name,
                "refdate": refdate,
            },
        )

        start_task >> source_to_silver >> inter_task

    dbt_run = DbtRunOperator(task_id=f"dbt_run_{SOURCE}_{ENVIRONMENT}")
    dbt_test = DbtTestOperator(task_id=f"dbt_test_{SOURCE}_{ENVIRONMENT}", retries=3)

    inter_task >> dbt_run >> dbt_test >> end_task
