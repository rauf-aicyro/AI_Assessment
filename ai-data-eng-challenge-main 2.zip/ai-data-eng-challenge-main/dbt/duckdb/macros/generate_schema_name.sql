{#
  Use the configured custom schema *as-is* (e.g. `silver`, `gold`) instead of dbt's default
  `<target_schema>_<custom_schema>`. This keeps the medallion schema names literal so the
  ingestion DAGs (which write `silver.<source>_<table>`) and `source('github', ...)` line up
  on the exact same DuckDB schema/table names.
#}
{% macro generate_schema_name(custom_schema_name, node) -%}
    {%- if custom_schema_name is none -%}
        {{ target.schema | trim }}
    {%- else -%}
        {{ custom_schema_name | trim }}
    {%- endif -%}
{%- endmacro %}
