{{
    config(
        materialized = 'incremental',
        on_schema_change = 'sync_all_columns',
        incremental_strategy = 'delete+insert',
        unique_key = 'id'
    )
}}

WITH
source_data AS (
    SELECT
        globex_order_lines.order_line_id::VARCHAR AS order_line_id
        , globex_order_lines.order_id::VARCHAR AS order_id
        , globex_order_lines.sku::VARCHAR AS sku
        , globex_order_lines.quantity::INTEGER AS quantity
        , globex_order_lines.unit_price::DECIMAL(18, 2) AS unit_price
        , globex_order_lines.updated_at::TIMESTAMP AS updated_at
        , globex_order_lines.refdate::VARCHAR AS refdate
    FROM {{ source('globex', 'globex_order_lines') }} AS globex_order_lines
    WHERE globex_order_lines.order_line_id IS NOT NULL
    {% if is_incremental() %}
        AND globex_order_lines.refdate >= (SELECT COALESCE(MAX(target.refdate), '0') FROM {{ this }} AS target)
    {% endif %}
)

, deduplicated AS (
    SELECT
        source_data.*
        , ROW_NUMBER() OVER (
            PARTITION BY source_data.order_line_id
            ORDER BY source_data.updated_at DESC
        ) AS row_num
    FROM source_data
)

SELECT
    MD5(deduplicated.order_line_id) AS id
    , deduplicated.order_line_id
    , deduplicated.order_id
    , deduplicated.sku
    , deduplicated.quantity
    , deduplicated.unit_price
    , deduplicated.updated_at
    , deduplicated.refdate
FROM deduplicated
WHERE deduplicated.row_num = 1
