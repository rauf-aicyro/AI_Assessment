{{
    config(
        materialized = 'incremental',
        on_schema_change = 'sync_all_columns',
        incremental_strategy = 'delete+insert',
        unique_key = 'id'
    )
}}

WITH
source_data AS (
    SELECT
        globex_orders.order_id::VARCHAR AS order_id
        , globex_orders.customer_id::VARCHAR AS customer_id
        , globex_orders.status::VARCHAR AS status
        , globex_orders.total_amount::DECIMAL(18, 2) AS total_amount
        , globex_orders.currency::VARCHAR AS currency
        , globex_orders.created_at::TIMESTAMP AS created_at
        , globex_orders.updated_at::TIMESTAMP AS updated_at
        , globex_orders.refdate::VARCHAR AS refdate
    FROM {{ source('globex', 'globex_orders') }} AS globex_orders
    WHERE globex_orders.order_id IS NOT NULL
    {% if is_incremental() %}
        AND globex_orders.refdate >= (SELECT COALESCE(MAX(target.refdate), '0') FROM {{ this }} AS target)
    {% endif %}
)

, deduplicated AS (
    SELECT
        source_data.*
        , ROW_NUMBER() OVER (
            PARTITION BY source_data.order_id
            ORDER BY source_data.updated_at DESC
        ) AS row_num
    FROM source_data
)

SELECT
    MD5(deduplicated.order_id) AS id
    , deduplicated.order_id
    , deduplicated.customer_id
    , deduplicated.status
    , deduplicated.total_amount
    , deduplicated.currency
    , deduplicated.created_at
    , deduplicated.updated_at
    , deduplicated.refdate
FROM deduplicated
WHERE deduplicated.row_num = 1
