provider "aws" {
  region = var.region

  # Placeholder credentials/role assumption omitted for the challenge.
  default_tags {
    tags = {
      Terraform = "true"
      System    = "data-platform"
    }
  }
}
