output "mwaa_webserver_urls" {
  description = "MWAA Airflow UI URL per environment."
  value       = { for env, mwaa in aws_mwaa_environment.this : env => mwaa.webserver_url }
}
