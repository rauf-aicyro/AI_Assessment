terraform {
  backend "remote" {
    organization = "<org>"
    workspaces {
      name = "data-infrastructure"
    }
  }
}
