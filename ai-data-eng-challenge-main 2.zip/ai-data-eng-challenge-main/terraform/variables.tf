variable "region" {
  type    = string
  default = "us-east-1"
}

variable "project" {
  type    = string
  default = "data-platform"
}

# Environments to create an MWAA environment for. mwaa.tf fans out over this set with for_each.
variable "environments" {
  type    = set(string)
  default = ["dev", "prod"]
}

variable "airflow_version" {
  type    = string
  default = "2.10.3"
}

# MWAA size per environment — prod runs a larger class than dev.
variable "environment_class" {
  type = map(string)
  default = {
    dev  = "mw1.small"
    prod = "mw1.medium"
  }
}

# Placeholder ARN of the MWAA execution role. NOT a real role — this challenge does not apply.
variable "mwaa_execution_role_arn" {
  type    = string
  default = "arn:aws:iam::111111111111:role/mwaa-execution-role"
}

# Placeholder networking. MWAA runs inside a VPC; these are NOT real ids.
variable "mwaa_subnet_ids" {
  type    = list(string)
  default = ["subnet-aaaaaaaa", "subnet-bbbbbbbb"]
}

variable "mwaa_security_group_ids" {
  type    = list(string)
  default = ["sg-aaaaaaaa"]
}
