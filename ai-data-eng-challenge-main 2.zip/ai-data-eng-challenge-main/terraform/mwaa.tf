# ---------------------------------------------------------------------------
# MWAA (Amazon Managed Workflows for Apache Airflow) environments.
#
# One environment per entry in var.environments (dev + prod).
# Only the size (environment_class) differs per environment;
# the execution role and networking are shared. Values are placeholders — this is for design review,
# not `apply`.
# ---------------------------------------------------------------------------

resource "aws_mwaa_environment" "this" {
  for_each = toset(var.environments)

  name               = "${var.project}-${each.key}"
  airflow_version    = var.airflow_version
  environment_class  = var.environment_class[each.key]
  execution_role_arn = var.mwaa_execution_role_arn

  # Per-env DAG source bucket (placeholder ARN), plus where DAGs live within it.
  source_bucket_arn = "placeholder ARN"
  dag_s3_path       = "dags/"

  network_configuration {
    security_group_ids = var.mwaa_security_group_ids
    subnet_ids         = var.mwaa_subnet_ids
  }

  logging_configuration {
    dag_processing_logs {
      enabled   = true
      log_level = "INFO"
    }
    scheduler_logs {
      enabled   = true
      log_level = "INFO"
    }
    task_logs {
      enabled   = true
      log_level = "INFO"
    }
  }

  tags = {
    Environment = each.key
  }
}
