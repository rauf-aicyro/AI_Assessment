# Take-Home: Add the "GitHub" vendor ingestion pipeline

You're onboarding a new source, **GitHub**, onto our ELT platform. You'll ingest two related
resources from the **GitHub REST API** (`https://api.github.com`) for a public repository of
your choice (e.g. `octocat/Hello-World`):

- `GET /repos/{owner}/{repo}/issues` — issues, incremental via `since`, paginated.
- `GET /repos/{owner}/{repo}/issues/comments` — issue comments (linked to issues via
  `issue_url`), same pagination/filtering.

Notes on the API contract (verify against
[the docs](https://docs.github.com/en/rest) — calling it for real is encouraged):

- **Auth**: `Authorization: Bearer <token>` (a GitHub PAT — see
  [Managing your personal access tokens](https://docs.github.com/en/authentication/keeping-your-account-and-data-secure/managing-your-personal-access-tokens)).
  Auth is *optional* — unauthenticated works at 60 req/hr, which is plenty for local testing; a
  token raises the limit to 5000/hr.
- **Pagination**: follow the **`Link: rel="next"`** response header (`requests` exposes it as
  `response.links`). GitHub serves cursor pagination here, so naively incrementing `?page=N`
  eventually returns `422` on large repos — follow the `next` link instead and stop when it's
  absent. Use `?per_page=100` to keep the page count down.
- **Incremental**: `?since=<ISO8601>` returns records with `updated_at >= since`. Pair with
  `sort=updated&direction=asc` for deterministic incremental pulls.
- **Response shape**: each endpoint returns a **top-level JSON array** (not wrapped in a
  `data`/`meta` envelope). Records are nested (e.g. `user.login`), so plan your flatten
  accordingly.

Follow the conventions in [AGENTS.md](./AGENTS.md) and use the **Globex** reference pipeline
(`airflow/dags/globex_files_to_silver/`) as a style guide. Globex is a *file-drop* source
(NDJSON files → silver); GitHub is an *API* source, so adapt the ingestion step rather than
copying it.

## Architecture in one line

There is **no S3 and no bronze layer**: ingestion lands flattened records straight into the
`silver` schema of a local **DuckDB** warehouse, and dbt builds the `gold` models from `silver`
in the same database. (DuckDB stands in for the cloud warehouse so everything runs on a laptop.)

```
GitHub API → silver.<source>_<table>  (DuckDB)  → gold dbt models (DuckDB)
```

---

## Part A — Ingestion DAG (Airflow)

1. Create `airflow/dags/github_api_to_silver/` following the folder/`dag.py` conventions (folder
   name matches the `dag_id` minus the `_{ENVIRONMENT}` suffix; orchestration only in
   `dag.py`, config in `assets.py`). **Schedule**: run **daily** with `catchup=False` (match the
   Globex reference's cadence; pick a different hour so the two DAGs don't contend).
2. **Build the API extraction utility from scratch** — there is intentionally no
   `utils/api_operations.py`. Create one (a paginated `GET` that loads records into `silver`).
   We like a small **source-strategy / factory** pattern (a class per source that builds
   headers + query params, registered in a factory) so new sources are easy to add — but the
   design is yours. Pull **both** endpoints incrementally:
   - **Incremental window / how far back**: use the previous successful run as the watermark
     (`prev_start_date_success` → `since`). On the **first run** (no prior success), backfill only
     a small *recent* window — the reference uses the **last 7 days** — so an unauthenticated run
     stays well under the 60 req/hr limit (a recent window is only a few API pages; a full-history
     backfill is hundreds and will get rate-limited). Make the window overridable (e.g. via an
     Airflow Variable) for a deliberate larger load with a token.
   - Land the records in `silver` via `DuckDBOperations.load_records_to_silver` (the provided
     warehouse helper — see `utils/duckdb_operations.py`). The gold dbt models read `silver`.
   - Re-runs must be **idempotent** (the helper does a `refdate`-partition replace; make sure
     you pass a stable `refdate`).
3. Read the GitHub token from an Airflow connection (backed by Secrets Manager in prod).
   Handle the no-token case gracefully (the API is usable unauthenticated for testing).
4. Your DAG must pass `tests/airflow/test_validation_airflow.py`.
5. Add at least one unit test for your extraction: mock the HTTP layer with `unittest.mock`,
   and load into a throwaway DuckDB file (`tmp_path`) to assert what landed in `silver`. See
   `tests/airflow/test_duckdb_operations_example.py` for the DuckDB pattern to copy.

## Part B — dbt gold models

Model the two silver tables (`github_issues`, `github_issue_comments`) into **analytics-ready
`gold` tables**, reading silver via `source()` (add `dbt/duckdb/models/sources/github.yml`). *How*
you model them is the point — make these calls and **justify them in your PR**:

1. **Materialization & load strategy.** Your DAG lands a new `refdate` partition every run, and the
   API re-emits issues/comments whenever they change (the `since` filter is on `updated_at`). Pick a
   materialization (and, if relevant, a load/merge strategy) that makes a **daily re-run cheap and
   correct**, and be ready to explain exactly what your reload predicate filters on and why.
2. **Grain & correctness.** Each entity must appear **once**, reflecting its **latest** state — no
   duplicates from re-emitted updates or overlapping `refdate` partitions. How you guarantee that is
   your call.
3. **Tests.** Add a `schema.yml` whose tests actually *enforce* the grain you claim (start with the
   natural key) plus any other invariant you rely on.
4. **Wire it in** so the DAG's dbt tasks build these models (`dbt_project.yml` — the `globex` block
   is a working example of the config shape).
5. `dbt run` / `dbt test --target duckdb` must succeed. Your **ingestion DAG** produces `silver`,
   and its `dbt_run`/`dbt_test` tasks build + test `gold` (the primary verification). To iterate on
   the models alone, point `DBT_DUCKDB_PATH` at the warehouse the DAG wrote — see the README.

### Gold output (the columns we expect downstream)

Whatever modeling you choose, each table should expose **at least** these fields (rename/cast freely,
add more if useful); flatten nested API fields (e.g. `user.login` → `user_login`):

- **`github_issues`** — `id`, `issue_number`, `title`, `state`, `user_login`, `comment_count`,
  `created_at`, `updated_at`, `refdate`.
- **`github_issue_comments`** — `id`, `user_login`, `body`, `created_at`, `updated_at`, `refdate`,
  plus a way to **join a comment back to its issue** (the silver comment carries `issue_url`).

## Part C — Terraform (create the MWAA source buckets)

This part is small and focused. The `terraform/` directory is **scaffolded for you** — provider,
versions, backend, variables, and the **MWAA** (Managed Airflow) environments in `mwaa.tf` are all
provided. `mwaa.tf` creates **two** environments (`dev` + `prod`) with per-environment sizing driven by the `environment_class` map and the execution role + networking shared.

The one thing missing: each MWAA environment loads its DAG code / `requirements.txt` / plugins
from a dedicated **S3 bucket**, but `mwaa.tf`'s `source_bucket_arn` currently points at a fake ARN
string. Your task:

1. Create a **per-environment** source S3 bucket (so `dev` and `prod` each get one):
   - **Security**: think about **encryption** and **public access**.
   - **Versioning**: it needs to support versioning.
   - **Tags**: at least `Name` + `Environment`, and a variable-driven bucket name.
2. **Wire it in** by editing the existing files: point `mwaa.tf`'s `source_bucket_arn`.
3. `terraform fmt` must pass (the only required check — CI runs it). This is a **design exercise**:
   no AWS account, and you do **not** `apply`. We review the HCL by hand against the reference.

**Tooling:** Terraform **>= 1.5.0** (pinned in `versions.tf`; AWS provider `~> 5.0`). Install and
verify via the README's *Terraform (Part C)* section (`terraform version` to confirm).

> **Bonus (not required):** refactor terraform code base into best practice structure to increase reusabability and readability.

---

## What we're evaluating

- **Production thinking**: idempotency, retries, error handling, partial-failure behaviour.
- **Ownership**: does it actually work end-to-end, not just compile?
- **Convention adherence**: you read and followed the existing patterns.
- **Terraform fluency**: a correct, well-structured production-grade Terraform configuration. A reusability earns bonus credit.
- **Communication**: clear PR description, trade-offs articulated, AI usage you can explain.

### How it's scored (weighting)

Each area is scored 1–5 (3 = meets the bar, 5 = excellent) and combined with the weights below.

| Part | Weight | What earns the marks |
|------|--------|----------------------|
| **Part A — Ingestion DAG (Airflow)** | **40%** | DAG imports & passes validation tests; API extraction util built from scratch (paginated `GET` → `silver`, source-strategy/factory); both endpoints pulled incrementally; clean `since` watermark & first-run backfill; sensible retries/timeouts/auth; a real unit test. **Idempotency & reliability live here**: re-runs don't duplicate (stable `refdate` partition replace), and you can reason about partial-page failures, pagination restarts, and late data. |
| **Part B — dbt gold models** | **25%** | Incremental materialization with a *justified* strategy and correct reload predicate; one row per natural key (dedupe on re-emitted updates); `not_null` + `unique` (and any invariant you rely on) tests that actually enforce the grain; `dbt run`/`test` pass; leading-comma / UPPERCASE-function style. |
| **Part C — Terraform** | **15%** | Per-env `mwaa_source` bucket via `for_each` (versioning + encryption + block-public-access, variable-driven, tagged), wired into `mwaa.tf`; `terraform fmt` clean. **Bonus:** a reusable bucket module and a clean story for adding `staging`. |
| **Conventions & code quality** | **10%** | Follows `AGENTS.md`; folder name == `dag_id`; typed code; `dag.py` orchestration-only; no committed secrets; would pass review with no nits. |
| **Communication (PR)** | **10%** | PR explains the approach and is runnable; clear trade-offs, "what I'd do with more time", and honest notes on what you used AI for (and what you rejected). |

**Indicative bar:** a weighted average of ≥4.3 is a strong submission, 3.5–4.2 is a solid pass,
3.0–3.4 is borderline, and <3.0 misses the bar. Green CI (`black`, DAG-validation tests,
`sqlfluff`, `terraform fmt`) is a baseline expectation, not bonus credit.

## Deliverable

A pull request against `main` from your feature branch, with **green CI** — the PR runs `black`,
the DAG-validation tests, and `sqlfluff`, and all must pass — and a description covering your
approach, trade-offs, how you used AI tools (and what you rejected), and what you'd improve with
more time.
